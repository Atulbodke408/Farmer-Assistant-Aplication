<?php
	$oldstr = "SELECT emp_sale.emp_id,emp_sale.trans_id,emp_sale.total_amount,emp_sale.paid_amount,emp_sale.balance_amount,emp_sale.updated_at,emp_sale.transaction_date,emp_sale.transaction_time,employee.emp_name,employee.phone_no FROM emp_sale inner join employee on employee.id = emp_sale.emp_id where admin_id = '1' and emp_id = '1' and transaction_date like '2021-09-13' order by updated_at desc";

$newstr = substr_replace($oldstr, 'sum(emp_sale.balance_amount) as total_pending_amount', 7, 0);

echo $newstr;


?>