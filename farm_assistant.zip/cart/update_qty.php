<?php
	@session_start();
	//print_r($_SESSION);
	$key = array_search($_POST['variant_id'], $_SESSION['variant_id']);    
	$_SESSION['qty'][$key] = $_POST['new_qty'];
	echo "qty_updated";
	
?>