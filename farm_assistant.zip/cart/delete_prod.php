<?php
    @session_start();
    //session_destroy();
    print_r($_POST);
    //remove the id from our cart array
   /* if(isset($_POST["delete_id"]))
    {
        $key = array_search($_POST['delete_id'], $_SESSION['cart']);    
        //echo $key;
        unset($_SESSION['cart'][$key]);
        $_SESSION['cart'] = array_values($_SESSION['cart']);
        $qty_val = $_POST['index'];
        //echo $qty_val; 

        unset($_SESSION['qty_array'][$qty_val]);
        //rearrange array after unset

        $_SESSION['qty_array'] = array_values($_SESSION['qty_array']);
        //array_push($_SESSION['qty_array'], "1");
        //$_SESSION['message'] = "Product deleted from cart";
        header('location: cart.php');
    }*/
     //print_r($_SESSION);
    
?>