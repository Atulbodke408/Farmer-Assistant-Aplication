<?php
  @session_start();
  //print_r($_SESSION);
 
	if (isset($_SESSION['user_id']) && isset($_SESSION['digit'])) {
		if($_SESSION['digit'] === $_POST['captcha_text'])
		{
			echo '1';
		}
		else
		{
			echo '0';
		}
	}
?>