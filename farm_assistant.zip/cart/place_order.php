<?php
	@session_start();
	//print_r($_POST);
	//print_r($_SESSION);
	require '../admin/db.php';
	$address ="";
	$time_slot_selected='';
	extract($_POST);
	$total = 0;
	$promo_code_text = "";
	$promo_discount = 0;

	for ($i=0; $i < count($_SESSION['variant_id']); $i++) { 
		$total += $_SESSION['price'][$i] * $_SESSION['qty'][$i];
	}
	extract($_SESSION);
	$otp = rand(111111,999999);
	$mobile = "";
	
	$select_address = "select user_addresses.mobile,user_addresses.address,user_addresses.landmark,user_addresses.pincode,user_addresses.state,user_addresses.country,area.name as areaname,city.name as cityname from user_addresses inner join city on city.id=user_addresses.city_id inner join area on area.id = user_addresses.area_id where user_id = '$user_id'";
	if ($result = $con->query($select_address)) {
	   while ($data = $result->fetch_assoc()) {
	   	$mobile = $data["mobile"];
	   	$address = $data['address'].', '.$data['landmark'].', '.$data['cityname'].', '.$data['areaname'].', '.$data['state'].', '.$data['country'].' Pin Code :'.$data['pincode'];
	   }
	}
	$select_promo = "select * from promo_codes where promo_code like '$promo_code'";
	
	if ($result = $con->query($select_promo)) {
	   while ($data = $result->fetch_assoc()) {
	   $promo_code_text = $data["promo_code"];
	   	if($data['discount_type'] == "percentage")
	   	{
	   		$promo_discount = $total * $data['discount'] / 100;
	   		$promo_discount > $data['max_discount_amount'] ? $promo_discount = $data['max_discount_amount'] : $promo_discount = $promo_discount;
	   	}
	   	else
	   	{
	   		$promo_discount = 0;
	   	}
	   }
	}
	$select_time_slot = "select * from time_slots where id = '$time_slot_selected'";
	if ($result = $con->query($select_time_slot)) {
	   while ($data = $result->fetch_assoc()) {
	   $time_slot_selected = $data['title'];
	   	
	   }
	}
	$final_total = $total - $promo_discount;

	$delivery_time = date('d-M-Y',strtotime($dateslot)).' - '.$time_slot_selected;
	$now = date('d-m-Y h:i:sa');

	$status = '[["received","'.$now.'"]]';
	$insert = "insert into orders (user_id,otp,mobile,order_note,total,promo_code,promo_discount,final_total,payment_method,address,delivery_time,status,active_status) values ('$user_id','$otp','$mobile','$del_extra_note','$total','$promo_code','$promo_discount','$final_total','$check_method','$address','$delivery_time','$status','received')";
	$order_master = mysqli_query($con,$insert);
	if($order_master)
	{
		$last_id = mysqli_insert_id($con);
		for ($i=0; $i < count($_SESSION['variant_id']); $i++) { 
			$product_variant_id = $_SESSION['variant_id'][$i];
			 $qty = $_SESSION['qty'][$i];
			$select = "select * from product_variant where id = $product_variant_id";
			if ($result = $con->query($select)) {
			   while ($data = $result->fetch_assoc()) {
				 
				  $price = $data['price'];
				  $discounted_price = $data['discounted_price'];

				  $insert_order_detail = "insert into order_items (user_id, order_id, product_variant_id, quantity, price,discounted_price,sub_total, status,active_status) values ('$user_id','$last_id','$product_variant_id','$qty','$price','$discounted_price','$final_total','$status','received')";
				  $fire = mysqli_query($con,$insert_order_detail);
				  $_SESSION['order_id'] = $last_id;
			   }
			}
			
		}
		echo "success";
				
		/**/
	}
	
	else
	{
		echo "fails";
	}
?>