<?php
    @session_start();
    //session_destroy();
    //print_r($_POST);
    //remove the id from our cart array
    if(!empty($_POST["variant_id"]))
    {
        $key = array_search($_POST['variant_id'], $_SESSION['variant_id']);    
        //echo $key;
        unset($_SESSION['variant_id'][$key]);
        $_SESSION['variant_id'] = array_values($_SESSION['variant_id']);
        
        unset($_SESSION['variant'][$key]);
        $_SESSION['variant'] = array_values($_SESSION['variant']);

         unset($_SESSION['price'][$key]);
        $_SESSION['price'] = array_values($_SESSION['price']);
        
        unset($_SESSION['qty'][$key]);
        $_SESSION['qty'] = array_values($_SESSION['qty']);

        unset($_SESSION['item_id'][$key]);
        $_SESSION['item_id'] = array_values($_SESSION['item_id']);
        echo "prod_removed";
        //array_push($_SESSION['qty_array'], "1");
        //$_SESSION['message'] = "Product deleted from cart";
        
    }
     //print_r($_SESSION);
    
?>