<?php
    require '../db.php';
    //print_r($_POST);
    //require 'header.php';
    session_start();
    $item_id=$_POST['prod_id'];
    $qty=$_POST['qty'];
     $user_id=$_SESSION['id'];
   // echo $qty;
    $add_to_cart_query="insert into users_items(user_id,prod_id,qty,status) values ('$user_id','$item_id','$qty','Added to cart')";
  //  echo $add_to_cart_query;

    $add_to_cart_result=mysqli_query($con,$add_to_cart_query) or die(mysqli_error($con));
    if ($add_to_cart_result) {
      echo "success";
       // code...
    }
    //header('location: products.php');
?>