<?php
include '../admin/db.php';
extract($_POST);
$password =md5($password);
$update = "update users set password='$password' where id='$userid'";
	$fire_query= mysqli_query($con,$update);
		
		if($fire_query)
		{
			echo "success";
		}
		else
		{
			echo "error";
		}
?>