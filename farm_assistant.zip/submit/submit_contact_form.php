<?php

 extract($_POST);

	require '../admin/db.php';
		$insert_query= "INSERT INTO contact_user(name,email,phone_no,subject,message) VALUES ('$name','$email','$phone_no','$subject','$message')";

		//echo $insert_query."<br>";	
		$fire_query= mysqli_query($con,$insert_query);
		//print_r($update_query_teacher);
		if($fire_query)
		{
			echo "success";
		}
		else
		{
			echo "error";
		}
	
?>
