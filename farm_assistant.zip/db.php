<?php
$con = mysqli_connect("localhost","root","","farm_assist");

//$con = mysqli_connect("localhost","sdcadmin_sdc","-MV;8D_PjH)c","sdcadmin_ecart");




if (mysqli_connect_errno())



  {



  echo "Failed to connect to MySQL: " . mysqli_connect_error();



  }



  else







  {


//echo 'success';
  	



  }


?>