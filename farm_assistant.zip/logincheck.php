<div class="col-md-6">
              <ul class="header-top-right pull-right">
               
            <li class="login afterremove">
                	  <a href="user_account.php"><i class="fa fa-user"></i>My Account</a>
                	</li>
                	<li class="register">
                	  <a href="logout.php">Logout</a>
                	</li>
               <li class="login">
                  <a href="login.php"><i class="fa fa-user"></i>Login</a>
                </li>
                <li class="register">
                  <a href="login.php">Register</a>
                </li>
              </ul>
            </div>