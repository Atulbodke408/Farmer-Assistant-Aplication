<?php
	extract($_POST);
	require '../admin/db.php';
	$select = "select * from user_addresses where id = '$id'";
	if($result = $con->query($select))
	{
	    while($data = $result->fetch_assoc())
	    {
		 echo '<div class="row">
					<div class="col-md-4 col-sm-12">
						<p style="margin-bottom: 0px">Name :</p>
						<input required style="width: 80%;border-radius: 5px;border-color: lightblue" type="text" name="user_name" value="'.$data["name"].'">
						<input  type="hidden" name="id" value="'.$data["id"].'">
						<input  type="hidden" name="user_id" value="'.$data["user_id"].'">
					</div>
					<div class="col-md-4 col-sm-12">
						<p style="margin-bottom: 0px">Mobile No. :</p>
						<input required style="width: 80%;border-radius: 5px;border-color: lightblue" type="text" name="user_mobile" value="'.$data["mobile"].'">
					</div>
					<div class="col-md-4 col-sm-12">
						<p style="margin-bottom: 0px">Alternate Mobile No. :</p>
						<input style="width: 80%;border-radius: 5px;border-color: lightblue" type="text" name="user_alternate_mobile" value="'.$data["alternate_mobile"].'">
					</div>
					
					<div class="col-md-4 col-sm-12" >
						<p style="margin-bottom: 0px"> Address :</p>
						<input required style="width: 80%;border-radius: 5px;border-color: lightblue" type="text" name="user_address" value="'.$data["address"].'">
					</div>
					<div class="col-md-4 col-sm-12">
						<p style="margin-bottom: 0px"> Landmark :</p>
						<input required style="width: 80%;border-radius: 5px;border-color: lightblue" type="text" name="user_landmark" value="'.$data["landmark"].'">
					</div>

					<div class="col-md-4 col-sm-12">
						<p style="margin-bottom: 0px"> Pincode :</p>
						<input required style="width: 80%;border-radius: 5px;border-color: lightblue" type="text" name="user_pincode" value="'.$data["pincode"].'">
					</div>
					
			
					

					<div class="col-md-4 col-sm-12">
						<p style="margin-bottom: 0px">City. :</p>
						<select required class="form-control" name="city_change_address" style="width: 80%;border-radius: 5px; border-color: lightblue;">
							<option  disabled value="">Select city</option>';
							
							$select_area = "select * from city";
							if($result2 = $con->query($select_area))
							{
							    while($data2 = $result2->fetch_assoc())
							    {
							    	if($data2["id"] == $data["city_id"])
							    	{
							    		echo '<option selected  value="'.$data2["id"].'">'.$data2["name"].'</option>';
							    	}
							    	else
							    	{
							    		echo '<option  value="'.$data2["id"].'">'.$data2["name"].'</option>';
							    	}
									
								}
							}
							echo '
						</select>
					</div>

					<div class="col-md-4 col-sm-12">
						<p style="margin-bottom: 0px">Area:</p>
						<select required class="form-control" name="area_change_address" style="width: 80%;border-radius: 5px; border-color: lightblue;">
							<option  disabled value="">Select Area</option>';
							
							$select_area = "select * from area";
							if($result2 = $con->query($select_area))
							{
							    while($data2 = $result2->fetch_assoc())
							    {
							    	if($data2["id"] == $data["area_id"])
							    	{
							    		echo '<option selected  value="'.$data2["id"].'">'.$data2["name"].'</option>';
							    	}
							    	else
							    	{
							    		echo '<option  value="'.$data2["id"].'">'.$data2["name"].'</option>';
							    	}
									
								}
							}
							echo '
						</select>
					</div>
					
					<div class="col-md-4 col-sm-12">
						<p style="margin-bottom: 0px"> State :</p>
						<input style="width: 80%;border-radius: 5px;border-color: lightblue" type="text" name="user_state" value="'.$data["state"].'">
					</div>';
					echo'<div class="col-md-4 col-sm-12">
						<p style="margin-bottom: 0px">Address Type:</p>
						<select required class="form-control" name="address_type" style="width: 80%;border-radius: 5px; border-color: lightblue;">
							<option value="" selected disabled>Select Address Type</option>';
							if($data["type"] == "Home")
							{
								echo '<option selected value="Home">Home</option>
							<option value="Work">Work</option>';
							}
							else if($data["type"] == "Work")
							{
								echo '<option  value="Home">Home</option>
							<option selected value="Work">Work</option>';
							}
							else {
									echo '<option  value="Home">Home</option>
								<option value="Work">Work</option>';
							}
							echo '
								
							
						</select>
					</div>';
                 

					if($data["is_default"] == "1")
					{
						echo '<div class="col-md-4 col-sm-12">
						<p style="margin-bottom: 0px"> Default : <span style="background-color:green;color:white;padding:10px">Yes</span></p>
						
					</div>';
					}
					else
					{
						echo '<div class="col-md-4 col-sm-12">
						<p style="margin-bottom: 0px">Set Default ?</p>
						<select required class="form-control" name="is_default" style="width: 80%;border-radius: 5px; border-color: lightblue;">
							<option selected  disabled value="">Select Option</option>
							<option value="1">Yes</option>
							<option value="0">No</option>
						</select>
					</div>';
					}

					
					echo'

					
					 
					
					
				</div>';
		}
	}
?>
