 <?php 
  extract($_POST);
  require '../admin/db.php';
 $select_area = "select * from area where city_id = '$selected_city'";
 $result2 = $con->query($select_area);
 $num_rows = mysqli_num_rows($result2);
 if($num_rows)
 {
 	echo '<option selected disabled value="">Select Area</option>';
     while($data2 = $result2->fetch_assoc())
     {
       
       	
         echo '<option value="'.$data2["id"].'">'.$data2["name"].'</option>';
       
     
   }
 }
 else
 {
 	echo '<option selected disabled value="">Sorry! No Areas available in selected city.</option>';
 }
?>