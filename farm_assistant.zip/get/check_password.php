<?php

    require '../admin/db.php';

   function getUpperPost($keepVar = false){
       $return_array = array();
          foreach($_POST as $postKey => $postVar){
           $return_array[$postKey] = strtoupper($postVar);
       }
       if($keepVar){
           $_POST = $return_array;
       }else{
           return $return_array;
       }
   }
    getUpperPost($_POST);
    extract($_POST);
    $mobileno = (string)$mobileno;
    
   $select = "select * from users where mobile = '$mobileno'";
  //   echo $select;
     $res = mysqli_query($con , $select);
     $num_rows = mysqli_num_rows($res);
     if($num_rows > 0)
     {
       echo "found";
     }
     else
     {
       echo "not_found";
     }
    
    
   
     
?>