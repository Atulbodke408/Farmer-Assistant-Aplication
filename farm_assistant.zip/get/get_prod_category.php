<?php
include "../admin/db.php";
extract($_POST);
$id =$_POST["cat_id"];
 $select = "select * from products  WHERE products.category_id='$id' limit 5";
 //echo $select;
 $result2 = $con->query($select);
 //$num_rows = mysqli_num_rows($result2);
 if($result2)
 {
 while ($data = $result2->fetch_assoc()) 
      {
      	echo ' <div class="dropdown-inner">
                  <ul class="list-unstyled childs_1">
                              
                      <li class="main_cat active"> <a  class="category_product">'.$data["name"].'</a> </li>

                   </ul>
                </div>
                 <li class="main_cat active"> <a href="products.php">View All</a> </li>';
      }
  }
  ?>