<?php
include "../admin/db.php";
extract($_POST);
$id =$_POST["cat_id"];
 $select = "select * from product_variant inner join products on products.id=product_variant.product_id WHERE products.category_id='$id'";
 //echo $select;
 $result2 = $con->query($select);
 //$num_rows = mysqli_num_rows($result2);
 if($result2)
 {
 while ($data = $result2->fetch_assoc()) 
      {
      	$realpath = dirname($data["image"]);
                        $path = str_replace($realpath, "", trim($data["image"]));
                        $path=  "admin/upload/images/".$path;
                    echo'
                           <div class="product-layout  product-grid col-lg-3 col-6 ">
                             <div class="item">
                               <div class="product-thumb transition">
	                              <div class="image">
	                                <div class="first_image"> <a href="product_detail_page.html"> <img src="'.$path.'" alt="pure-spice-3" title="pure-spice-3" class="img-responsive"> </a> </div>
	                                <div class="swap_image"> <a href="product_detail_page.html"> <img src="'.$path.'" alt="pure-spice-3" title="pure-spice-3" class="img-responsive"> </a></div>
	                              </div>
                                 <div class="product-details">
                                   <div class="caption">
	                                  <h4><a href="product_detail_page.html">'.$data["name"].'</a></h4>
	                                  <p class="price">$'.$data["price"].'<span class="price-tax">Ex Tax: $7.25</span></p>
	                                  <p class="desc">freshly picked for you.Store them in a cool, dry place away from direct sunlight...</p>
	                                   <div class="product_option">

		                                    <div class="input-group button-group">
		                                      <label class="control-label">Qty</label>
		                                      <input type="number" name="quantity" min="1" value="1"  step="1" class="qty form-control">
		                                      <button type="button" class="addtocart pull-right">Add</button>
		                                    </div>
	                                   </div>
                                   </div>
                                 </div>
                               </div>
                             </div>
                           </div>
                       ';
      }
    
 }
 else
 {
 	echo "error";
 }
?>