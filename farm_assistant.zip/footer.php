 <div class="footer section pt-40">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 footer-block">
            <h4 class="footer-title py-2">Information</h4>
            <ul>
              <li><a href="#">About Us</a></li>
              <li><a href="#">Delivery Information</a></li>
              <li><a href="#">Privacy Policy</a></li>
              <li><a href="#">Terms & Conditions</a></li>

            </ul>
          </div>
            <div class="col-lg-3 footer-block">
            <h4 class="footer-title py-2">Extras</h4>
            <ul>
              <li><a href="#">Brands</a></li>
           
              <li><a href="#">Affiliates</a></li>
              <li><a href="#">Specials</a></li>
            </ul>
          </div>
          <div class="col-lg-3 footer-block">
            <h4 class="footer-title py-2">Services</h4>
            <ul>

              
             <li><a href="#">Contact Us</a></li>
            </ul>
          </div>
         <!--  <div class="col-lg-3 footer-block">
            <h4 class="footer-title py-2">Users</h4>
            <ul>
              <li><a href="user_account.php">My Account</a></li>
              <li><a href="user_orders.php">Orders</a></li>
              <li><a href="user_address.php">Addresses</a></li>
              <li><a href="user_returns.php">Returns</a></li>
             
            </ul>
          </div> -->
          <div class="col-lg-3 footer-block">
            <h4 class="footer-title py-2">Contacts</h4>
            <ul>
              <li class="add">Nashik, Maharashtra 422001</li>
              <li class="phone">(+123) 456 789
               </li>
              <li class="email">info@.com</li>

            </ul>
            <ul>
                  
                </ul>
              
          </div>
        </div>
        <!-- =====  Newslatter ===== -->
    <!--     <div class="newsletters mt-30">
          <div class="news-head pull-left">
            <h2>Subscribe for Latest offers and News</h2>
          </div>
          <div class="news-form pull-right">
            <form onsubmit="return validatemail();" method="post">
              <div class="form-group required">
                <input name="email" id="email" placeholder="Enter Your Email" class="form-control input-lg" required="" type="email">
                <button type="submit" class="btn btn-default btn-lg">Subscribe</button>
              </div>
            </form>
          </div>
        </div> -->
        <!-- =====  Newslatter End ===== -->
      </div>

      <div class="footer-bottom">
        <div class="container">
          <div class="row">
     

     <!--        <div class="col-12 col-lg-6 mt-20">
              <div class="section_title">Download our app</div>
              <div class="app-download text-center">
                <ul class="app-icon">
                  <li><a href="#" title="playstore"><img src="images/play-store.png" alt="playstore" class="img-responsive"></a></li>
                  
                </ul>
              </div>
            </div> -->
            
            <div class="col-12 ">
              <div class="copyright-part text-center pt-10 pb-10 mt-30">Designed & Developed By <a href="https://kaikotech.com"></a></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>