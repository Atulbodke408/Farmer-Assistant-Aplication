<?php
	@session_start();
	extract($_POST);
	!empty($promo_code_valid) ? $_SESSION['promo_code'] = $promo_code_valid : $_SESSION['promo_code'] = "";

	$_SESSION['cart_amt'] = $cart_amt;
	$_SESSION['promo_disc_amt'] = $promo_disc_amt;
	$_SESSION['cart_final_amt'] = $cart_final_amt;
?>