<?php
	@session_start();
	extract($_POST);
	!empty($address_id) ? $_SESSION['address_id'] = $address_id : $_SESSION['address_id'] = "";
?>